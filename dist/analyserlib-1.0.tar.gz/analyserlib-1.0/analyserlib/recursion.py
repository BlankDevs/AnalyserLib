def sum_array(array):

    '''Return sum of all items in array'''



def fibonacci(n):

    '''Return nth term in fibonacci sequence'''



def factorial(n):

    '''Return n!'''



def reverse(word):

    '''Return word in reverse'''


