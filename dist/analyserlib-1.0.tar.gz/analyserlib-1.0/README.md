# Analyser

Analyser is a Python based library for sorting items and performing operations on them recursively.

## Vesrion

v1.0


## Installation

To install the package use the packet manager pip:
```bash
pip install git+https://github.com/BlankDevs/analyserlib.git
```


If you need to install the lastest version of the package, then use:
```bash
pip install --upgrade git+https://github.com/BlankDevs/analyserlib.git
```
package requires 'numpy'

## Contribution

PLACE CONTRIBUTION

## License

PLACE LICENSE